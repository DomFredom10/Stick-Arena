STICK ARENA — instalação online

O HTML inclui VS BOTS e TREINO INFINITO local. Para o MULTIPLAYER funcionar em dois Chromes/computadores, é necessário publicar o servidor.

PUBLICAR NO RENDER:
1. Envie todos os arquivos desta pasta para um repositório GitHub.
2. No Render, crie um Web Service conectado ao repositório.
3. Build Command: npm install
4. Start Command: npm start
5. Aguarde o deploy e abra a URL HTTPS gerada.
6. Os dois jogadores abrem essa mesma URL. Um clica CRIAR PARTIDA e envia o código ao outro. O outro digita o código e clica ENTRAR.

Cada jogador começa com 3 vidas. Quando cai, perde uma vida e reaparece. Ao perder as 3, sai da disputa.

IMPORTANTE: abrir o index.html diretamente como arquivo permite os modos locais, mas não multiplayer. Multiplayer só funciona pela URL do servidor com Socket.IO.
