const express=require('express');
const http=require('http');
const {Server}=require('socket.io');
const crypto=require('crypto');
const app=express(),server=http.createServer(app),io=new Server(server);
app.use(express.static('public'));
const rooms=new Map();
function code(){let s;do{s=crypto.randomBytes(3).toString('hex').toUpperCase()}while(rooms.has(s));return s}
function state(room){return {players:Object.fromEntries([...room.players.entries()].map(([id,p])=>[id,{id,x:p.x,y:p.y,vx:p.vx,vy:p.vy,face:p.face,lives:p.lives,attacking:p.attacking}]))}}
function broadcast(code){let r=rooms.get(code);if(r)io.to(code).emit('state',state(r))}
function fall(id,roomCode){let r=rooms.get(roomCode);if(!r)return;let p=r.players.get(id);if(!p||p.lives<=0)return;p.lives--;p.x=480+(Math.random()*80-40);p.y=270+(Math.random()*80-40);p.vx=p.vy=0;p.attacking=false;io.to(roomCode).emit('knockout',{id,lives:p.lives});broadcast(roomCode)}
io.on('connection',socket=>{
 socket.on('createRoom',()=>{let c=code(),r={players:new Map()};rooms.set(c,r);socket.join(c);socket.data.room=c;r.players.set(socket.id,{x:270,y:270,vx:0,vy:0,face:1,lives:3,attacking:false});socket.emit('roomCreated',{code:c});broadcast(c)});
 socket.on('joinRoom',c=>{c=String(c||'').toUpperCase().replace(/[^A-F0-9]/g,'');let r=rooms.get(c);if(!r){socket.emit('roomError',{message:'Código não encontrado. Confira e tente novamente.'});return}if(r.players.size>=2){socket.emit('roomError',{message:'Essa sala já está cheia.'});return}socket.join(c);socket.data.room=c;r.players.set(socket.id,{x:690,y:270,vx:0,vy:0,face:-1,lives:3,attacking:false});socket.emit('joinedRoom',{code:c});broadcast(c)});
 socket.on('move,dummy',()=>{});
 socket.on('move',d=>{let c=socket.data.room,r=rooms.get(c),p=r&&r.players.get(socket.id);if(!p||p.lives<=0)return;p.x=Math.max(0,Math.min(960,Number(d.x)||0));p.y=Math.max(0,Math.min(540,Number(d.y)||0));p.vx=Number(d.vx)||0;p.vy=Number(d.vy)||0;p.face=Number(d.face)||1;broadcast(c)});
 socket.on('attack',d=>{let c=socket.data.room,r=rooms.get(c),p=r&&r.players.get(socket.id);if(!p||p.lives<=0)return;p.attacking=true;for(let [id,o] of r.players){if(id===socket.id||o.lives<=0)continue;let dx=o.x-p.x,dy=o.y-p.y;if(Math.hypot(dx,dy)<125&&dx*(Number(d.face)||1)>-20&&Math.abs(dy)<95){o.vx+=(Number(d.face)||1)*24;o.vy+=(dy/(Math.hypot(dx,dy)||1))*12;let edge=o.x<45||o.x>915||o.y<45||o.y>495;if(edge)fall(id,c)}}setTimeout(()=>{let rr=rooms.get(c),pp=rr&&rr.players.get(socket.id);if(pp)pp.attacking=false;broadcast(c)},180);broadcast(c)});
 socket.on('fell',()=>{let c=socket.data.room;if(c)fall(socket.id,c)});
 socket.on('disconnect',()=>{let c=socket.data.room,r=rooms.get(c);if(!r)return;r.players.delete(socket.id);socket.to(c).emit('opponentLeft');if(r.players.size===0)rooms.delete(c);else broadcast(c)});
});
const PORT=process.env.PORT||3000;server.listen(PORT,'0.0.0.0',()=>console.log('STICK ARENA online na porta '+PORT));
